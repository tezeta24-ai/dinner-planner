# Maki & Banji Engagement Dinner Planner

## Deploy to Vercel (free, ~5 minutes)

### Step 1 — Get the code on GitHub
1. Go to github.com and create a free account if you don't have one
2. Click **+** → **New repository** → name it `dinner-planner` → Create
3. Upload these files: `api/lookup.js`, `public/index.html`, `package.json`, `vercel.json`

### Step 2 — Deploy on Vercel
1. Go to vercel.com → Sign up with your GitHub account
2. Click **Add New → Project** → import your `dinner-planner` repo
3. Click **Deploy** (leave all settings as default)

### Step 3 — Add your Anthropic API key
1. In Vercel, go to your project → **Settings → Environment Variables**
2. Add: `ANTHROPIC_API_KEY` = your key from console.anthropic.com
3. Click **Redeploy**

### Done!
Vercel gives you a URL like `dinner-planner.vercel.app` — share it with your friend!
